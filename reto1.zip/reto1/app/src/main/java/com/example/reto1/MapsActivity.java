package com.example.reto1;

import androidx.annotation.Nullable;
import androidx.fragment.app.FragmentActivity;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.graphics.Color;
import android.location.Address;
import android.location.Geocoder;
import android.location.Location;
import android.location.LocationManager;
import android.location.LocationProvider;
import android.os.Bundle;
import android.util.Log;
import android.widget.TextView;

import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.GoogleMap.OnMapClickListener;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.BitmapDescriptorFactory;
import com.google.android.gms.maps.model.Circle;
import com.google.android.gms.maps.model.CircleOptions;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.Marker;
import com.google.android.gms.maps.model.MarkerOptions;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.maps.android.SphericalUtil;

import java.io.IOException;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

public class MapsActivity extends FragmentActivity implements OnMapReadyCallback, LocationProvider.OnLocationReceivedListener, GoogleMap.OnMapClickListener {

    private GoogleMap mMap;
    private Marker actual;
    private TextView tvinfo;
    private FloatingActionButton btn_add;
    private Geocoder geocoder;
    private Marker tempo;
    private ArrayList<Marker> marcadores;
    private ArrayList<Double> distancias;
    private int posMenor;

    private LocationProvider gpsProvider;
    private LocationProvider networkProvider;

    private double minAccuracy = 1000;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_maps);
        // Obtain the SupportMapFragment and get notified when the map is ready to be used.
        SupportMapFragment mapFragment = (SupportMapFragment) getSupportFragmentManager()
                .findFragmentById(R.id.map);
        mapFragment.getMapAsync(this);

        geocoder = new Geocoder(this, Locale.getDefault());
        tvinfo = findViewById(R.id.tvinfo);
        marcadores = new ArrayList<Marker>();
        distancias = new ArrayList<Double>();

        btn_add = findViewById(R.id.floatingActionButton);
        btn_add.setOnClickListener(
                (v) -> {
                    if (tempo != null) {
                        Intent i = new Intent(this, AddMarkers.class);
                        Marcador m = new Marcador(tempo.getTitle());
                        i.putExtra("marcador", m);
                        startActivityForResult(i, 11);
                    }
                }
        );

    }
}