package com.example.reto1;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class AnadirMarkers extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_anadir_markers);
    }
}
